import React from 'react';
import { StyledButton } from './StyledComponents';


export function ThemeProvider() {
    return (
      <div>
        <StyledButton>Learn More</StyledButton>
      </div>
    );
  }
