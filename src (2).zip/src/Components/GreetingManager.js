import React,{useState} from 'react';

export default function GreetingManager() {

    const [name,setName]=useState('')
  return (
    <div>
      
    </div>
  );
}
