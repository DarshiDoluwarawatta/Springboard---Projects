import React from 'react';
import { Stack } from '@mui/material';
import {  Heading2  } from '../Components/StyledComponents';
import "../Styles/SimpleCard.css";

// eslint-disable-next-line import/no-anonymous-default-export
export default function() {
  return (
    <>
    
        <div>
        <Heading2 ><b>Contact Us:</b></Heading2><p></p>
            <p className='card-container-p'> 2/384,Wekkawatta,<br/>Ihala Bomiriya,<br/>Kaduwela.<br/><br/> Tel: 075 655 7045. <br/>Email: ddoluweera75@gmail.com</p>
        </div>
        
       
    
      </>
              
  );
}
