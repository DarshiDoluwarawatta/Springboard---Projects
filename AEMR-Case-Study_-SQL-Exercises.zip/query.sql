

SELECT Participant_Code,Facility_Code,Status,extract(year from Start_Time) as Year,Round(Avg(Outage_MW),2) as Avg_Outage_MW_Loss,Round(sum(Outage_MW),2) as Summed_Energy_Lost
From AEMR
WHERE
	 Reason='Forced'and Status='Approved'
group by Participant_Code,Facility_Code,Status,Year
order by Year ASC,Summed_Energy_Lost DESC;





  
